
#include <iostream>
#include <array>
using namespace std;

void printArray(int numbers[], int size)
{
	for (int c = 0; c < size; c++)
	{
		cout << numbers[c] << " ";
	}
	cout << endl;
}

void bubbleSort(int numbers[],int size)
{
	int tempint;
	for (int stop = size - 1; stop > 0; stop--)
	{
		for (int c = 0; c < stop; c++)
		{
			if (numbers[c] > numbers[c + 1])
			{
				tempint = numbers[c];
				numbers[c] = numbers[c + 1];
				numbers[c + 1] = tempint;
			}
			printArray(numbers,size);
		}
	}
}

int main()
{
	int numbers[6] = {50,15,28,1,23,22};
	bubbleSort(numbers, 6);
	return 0;
}

